var fmDashRss = {};
fmDashRss.refreshInterval = 20; //seconds
fmDashRss.appVPath = '/plugins/FergusonMoriyama/DashRss';
fmDashRss.css = false;

var f = window.document;
var head = f.getElementsByTagName('head')[0];
	    


fmDashRss.renderFeed = function(id, umbracoPath) {
    if(!fmDashRss.css) {
        fmDashRss.css = true;
        var script = f.createElement("link");
        script.setAttribute("rel", "stylesheet");
        script.setAttribute("type", "text/css");
        script.setAttribute("href", umbracoPath + fmDashRss.appVPath + '/dashrss.css');
        head.appendChild(script);
    }
    
    if(!fmDashRss.loadingGif) { 
        fmDashRss.loadingGif = umbracoPath + fmDashRss.appVPath + '/ajax-loader.gif';
        fmDashRss.loadingGif = '<img src="'+fmDashRss.loadingGif+'" alt="Loading" width="16" height="16"/>';
    }
    
    


    var containerId = $('#'+id).parent().parent().attr('id');
    containerId = containerId.replace(/^(.*?\_tab\d{2}).*$/, "$1");
    var tabName = $('#' + containerId + ' span nobr').html();
    fmDashRss.load(id, tabName, umbracoPath);
}

fmDashRss.load = function(elementId, feedId, umbracoPath) {
    
    $('#'+ elementId).prepend('<p class="loading">Loading ' + fmDashRss.loadingGif + '</p>');
    
    var tsTimeStamp= new Date().getTime();
    
    $.get(umbracoPath + fmDashRss.appVPath + '/RssProxy.aspx', { feed: escape(feedId), time: tsTimeStamp },
        function(data){
            $('#'+ elementId + ' p.loading').fadeOut('slow', function() {
               
                $('#'+ elementId + ' p.loading').remove();
                $('#'+ elementId).html(data);
                setTimeout("fmDashRss.load('" + elementId + "', '" + feedId + "', '" +umbracoPath +"')", fmDashRss.refreshInterval * 1000);
            });
            
        }
   )

}

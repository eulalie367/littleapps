﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Text.RegularExpressions;

namespace Gravatar4Umbraco
{
    public partial class Gravatar : System.Web.UI.UserControl
    {
        private string _emailaddress, _alertnatetext, _DefaultImage, _rating, _iconType;
        private int _imagewidth, _imageheight;
        private bool _usedefaultimages;
        
        public int ImageWidth { get { return _imagewidth; } set { _imagewidth = value; } }
        public int ImageHeight { get { return _imageheight; } set { _imageheight = value; } }
     

        public string EmailAddress
        {
            get { return _emailaddress; }
            set { _emailaddress = value; }
        }

        public string AlternateText
        {
            get { return _alertnatetext; }
            set { _alertnatetext = value; }
        }

        public string DefaultImage
        {
            get { return _DefaultImage; }
            set { _DefaultImage = value; }
        }

        public string Rating
        {
            get { return _rating; }
            set { _rating = value; }
        }

        public bool UseIconsIfNoImage
        {
            get { return _usedefaultimages; }
            set { _usedefaultimages = value; }
        }

        public string IconToUse
        {
            get { return _iconType; }
            set { _iconType = value; }
        }



        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                string maxSize;
                if (_imagewidth > _imageheight)
                {
                    maxSize = _imagewidth.ToString() + "px";
                }
                else
                {
                    maxSize = _imageheight.ToString() + "px";
                }

                imgGravatar.Width = _imagewidth;
                imgGravatar.Height = _imageheight;
                imgGravatar.ImageUrl = GetGravatarURL(_emailaddress, maxSize, _usedefaultimages, _iconType, _DefaultImage);
                imgGravatar.AlternateText = _alertnatetext;                                              

            }
        }

        public static string GetGravatarURL(string email, string size)
        {

            return (string.Format("http://www.gravatar.com/avatar/{0}?s={1}",

                EncryptMD5(email), size));

        }

        public string GetGravatarURL(string email, string size, bool UseIconsIfNoImage, string IconType, string defaultImagePath)
        {
            string imageUrl;

            if (UseIconsIfNoImage == false)
            {
                imageUrl = GetUrlImageByMediaId(defaultImagePath);
            }
            else
            {
                imageUrl = IconType;
            }

            return GetGravatarURL(email, size) + string.Format("&d={0}", imageUrl) + string.Format("&r=", _rating);

        }



        private static string EncryptMD5(string Value)
        {

            System.Security.Cryptography.MD5CryptoServiceProvider md5 = new MD5CryptoServiceProvider();

            byte[] valueArray = System.Text.Encoding.ASCII.GetBytes(Value);

            valueArray = md5.ComputeHash(valueArray);

            string encrypted = "";

            for (int i = 0; i < valueArray.Length; i++)

                encrypted += valueArray[i].ToString("x2").ToLower();

            return encrypted;

        }

        private string GetUrlImageByMediaId(string stringNodeId)
        {
            string mediaUrl = "";
            int intNodeId = 0; if (int.TryParse(stringNodeId, out intNodeId))
            {
                System.Xml.XmlNode node = (umbraco.library.GetMedia(intNodeId, false).Current as System.Xml.IHasXmlNode).GetNode(); if (node != null)
                   mediaUrl = node.SelectNodes("//data[@alias='umbracoFile']")[0].InnerText;
            }

            
            return  Server.UrlEncode(GetApplicationPath() + mediaUrl.Replace("//media", "/media"));
        }

        public string GetApplicationPath()
        {
            string applicationPath = "";

            if (this.Page.Request.Url != null)
                applicationPath = this.Page.Request.Url.AbsoluteUri.Substring(
                 0, this.Request.Url.AbsoluteUri.ToLower().IndexOf(
                  this.Request.ApplicationPath.ToLower(),
                   this.Request.Url.AbsoluteUri.ToLower().IndexOf(
                  this.Page.Request.Url.Authority.ToLower()) +
                  this.Page.Request.Url.Authority.Length) +
                 this.Request.ApplicationPath.Length);
            return applicationPath;
        }



    }
}
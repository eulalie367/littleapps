﻿function DeleteAppTree(appTreeAlias) {
    openModal('/umbraco/plugins/appmanager/deleteDialog.aspx?appTreeAlias=' + appTreeAlias, 'Delete Umbraco AppTree', 250, 480);
}

function DeleteApp(appAlias) {
    openModal('/umbraco/plugins/appmanager/deleteDialog.aspx?appAlias=' + appAlias, 'Delete Umbraco App', 250, 480);
}